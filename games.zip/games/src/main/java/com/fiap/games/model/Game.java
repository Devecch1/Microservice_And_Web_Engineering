package com.fiap.games.model;

public class Game {

    private String nome;

    private Double valor;

    private String tipo;

    private String console;

    public Game(String nome, Double valor, String tipo, String console) {
        this.nome = nome;
        this.valor = valor;
        this.tipo = tipo;
        this.console = console;
    }

    public Game(){

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getConsole() {
        return console;
    }

    public void setConsole(String console) {
        this.console = console;
    }

}
