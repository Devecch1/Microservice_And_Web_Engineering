package com.fiap.games.controller;


import com.fiap.games.model.Game;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Arrays;
import java.util.List;

@Controller
@RequestMapping("/jogo")
public class GameController {

    @GetMapping
    public ModelAndView pegarJogo(){
        ModelAndView modelView = new ModelAndView("game/index.html");

        Game game1 = new Game("Crash", 20.0, "Acao", "Play 2");
        Game game2 = new Game("God Of War", 150.0, "Acao e Aventura", "Play 5");

        List<Game> jogos = Arrays.asList(game1,game2);

        modelView.addObject("listaJogos", jogos);

        return modelView;
    }

}
